import pyttsx3

engine = pyttsx3.init()

def play_audio(text):
    engine.say(text)
    engine.runAndWait()