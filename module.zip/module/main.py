# main.py
import argparse
from multiprocessing import Process, Queue, Event, cpu_count
import time
from video_reader import video_reader_process
from detection import detector_tracker_process
from decision import feature_mlp_rule_process
from output_writer import output_writer_process
from utils.general import check_requirements

def parse_opt():
    parser = argparse.ArgumentParser()
    parser.add_argument('--weights', nargs='+', type=str, default=['best.pt'], help='model path(s)')  # Sử dụng model nano mặc định
    parser.add_argument('--source', type=str, default='data/images', help='file/dir/URL/glob, 0 for webcam')
    parser.add_argument('--imgsz', '--img', '--img-size', nargs='+', type=int, default=[320], help='inference size h,w')  # Giảm kích thước mặc định
    parser.add_argument('--conf-thres', type=float, default=0.3, help='confidence threshold')  # Tăng ngưỡng
    parser.add_argument('--iou-thres', type=float, default=0.5, help='NMS IoU threshold')
    parser.add_argument('--device', default='cpu', help='cuda device')  # Luôn sử dụng CPU
    parser.add_argument('--view-img', action='store_true', help='show results')
    parser.add_argument('--nosave', action='store_true', help='do not save images/videos')
    parser.add_argument('--project', default='runs/detect', help='save results to project/name')
    parser.add_argument('--name', default='exp', help='save results to project/name')
    parser.add_argument('--exist-ok', action='store_true', help='existing project/name ok')
    parser.add_argument('--max-fps', type=int, default=15, help='maximum FPS for processing')  # Giới hạn FPS
    opt = parser.parse_args()
    opt.imgsz *= 2 if len(opt.imgsz) == 1 else 1
    return opt

def main(opt):
    check_requirements(exclude=('tensorboard', 'thop'))
    
    # Giới hạn số process để tránh quá tải
    max_processes = min(4, cpu_count())
    
    # Tạo queues và event
    frame_queue = Queue(maxsize=10)  # Giảm kích thước queue
    detect_queue = Queue(maxsize=10)
    output_queue = Queue(maxsize=10)
    stop_event = Event()
    
    # Tạo processes
    processes = [
        Process(target=video_reader_process, args=(opt.source, opt.imgsz, 32, frame_queue, stop_event)),
        Process(target=detector_tracker_process, args=(opt.weights, opt.imgsz, opt.conf_thres, opt.iou_thres, 
                                                    opt.device, frame_queue, detect_queue, stop_event)),
        Process(target=feature_mlp_rule_process, args=(detect_queue, output_queue, stop_event)),
        Process(target=output_writer_process, args=(output_queue, stop_event, opt.project, opt.name, 
                                                opt.view_img, opt.nosave, opt.exist_ok))
    ]
    
    # Ưu tiên process cho module quan trọng
    processes[0].daemon = True  # Video reader
    processes[1].daemon = True  # Detector tracker
    processes[2].daemon = False  # Feature MLP (quan trọng)
    processes[3].daemon = True  # Output writer
    
    # Khởi chạy processes
    for p in processes:
        p.start()
    
    # Chờ các processes hoàn thành
    try:
        # Chỉ chờ process quan trọng nhất
        processes[2].join()
    except KeyboardInterrupt:
        print("Đang dừng...")
        stop_event.set()
        for p in processes:
            if p.is_alive():
                p.terminate()
            p.join()

if __name__ == "__main__":
    opt = parse_opt()
    main(opt)