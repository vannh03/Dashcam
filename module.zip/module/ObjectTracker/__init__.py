""" Initializes the object_tracking module """

from .core import ObjectTrackBase
from .byteTrack.byteTracker import BYTETracker
