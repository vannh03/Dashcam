import math

def estimate_distance(bbox, class_name, frame_width=2560, horizontal_fov=130):
    """
    Tính khoảng cách dựa trên kích thước vật thể và thông số camera
    
    Args:
        bbox: (x1, y1, x2, y2) bounding box coordinates
        class_name: tên class đối tượng
        frame_width: chiều rộng khung hình (pixel)
        horizontal_fov: góc nhìn ngang camera (độ)
    """
    height_pixel = bbox[3] - bbox[1]  # y2 - y1
    if height_pixel <= 0:
        return -1

    # Chuyển đổi FOV sang tiêu cự (focal length) tính bằng pixel
    focal_length_px = (frame_width / 2) / math.tan(math.radians(horizontal_fov / 2))
    
    # Chiều cao thực tế các đối tượng (đơn vị mét)
    real_heights = {
        "person": 1.6,      # 1.6m ~ 160cm
        "bicycle": 1.0,     # 1.0m
        "motorcycle": 1.2,  # 1.2m
        "car": 1.5,         # 1.5m
        "bus": 3.2,         # 3.2m
        "truck": 3.5,       # 3.5m
    }
    
    # Lấy chiều cao thực tế (mét)
    real_height = real_heights.get(class_name.lower(), 1.6)  # Mặc định 1.6m nếu không tìm thấy
    
    # Tính khoảng cách theo công thức: distance = (real_height * focal_length_px) / height_pixel
    distance_m = (real_height * focal_length_px) / height_pixel
    
    return round(distance_m, 2)