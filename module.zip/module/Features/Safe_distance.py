from PIL import Image 
import pytesseract
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
import re
import cv2

last_speed = 0 
muy = 0.8
g = 9.8
def extract_speed(text):
    if not text:
        return None
    text = re.sub(r'\bO(?=km/h)', '0', text)  
    text = re.sub(r'\bQ(?=km/h)', '0', text)  
    text = re.sub(r'\bB(?=km/h)', '8', text)  

    text = re.sub(r'(\d)\s+km/h', r'\1km/h', text)
    match = re.search(r'\b(\d{1,3})km/h\b', text)
    if match:
        return int(match.group(1))
    else:
        return None
def get_speed(frame):
    xmin, ymin, xmax, ymax =  1390, 1742, 2555, 1918
    roi = frame[ymin:ymax, xmin:xmax]
    pil_img = Image.fromarray(cv2.cvtColor(roi, cv2.COLOR_BGR2RGB))
    text = pytesseract.image_to_string(pil_img)
    speed = extract_speed(text)
    # print(f'Text of frame :{text},  Speed : {speed}')
    return speed

def safe_distance_estimation(frame):
    global last_speed
    
    speed = get_speed(frame)  
    safe_distance = 0

    if speed is None or speed == 0:
        # print('No speed detected, using last speed')
        speed = last_speed
    else:
        speed = int(speed)
        last_speed = speed
    speed = int(speed * 1000 / 3600)
    safe_distance = int(speed**2 / (2 * muy * g))
    total_distance = int(speed + safe_distance)
    return speed, total_distance
    
