import math
import numpy as np
def compute_angle(x, y, EGO_POSITION):
    dx = x - EGO_POSITION[0]
    dy = EGO_POSITION[1] - y
    if dx != 0 or dy != 0:
        current_angle = math.degrees(math.atan2(dy, dx))
    else:
        return 0
    angle_sin= np.sin(np.deg2rad(current_angle))
    angle_cos = np.cos(np.deg2rad(current_angle))
    return current_angle, angle_sin, angle_cos