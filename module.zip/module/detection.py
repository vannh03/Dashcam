# detector_tracker.py
import torch
import numpy as np
from ultralytics import YOLO
from utils.general import scale_coords
from ObjectTracker.byteTrack.byteTracker import BYTETracker
import time
import cv2


class BYTETrackerArgs:
    def __init__(self):
        self.track_thresh = 0.3
        self.track_buffer = 30
        self.match_thresh = 0.8
        self.frame_rate = 30
        self.min_box_area = 10

def detector_tracker_process(weights, imgsz, conf_thres, iou_thres, device, 
                            frame_queue, detect_queue, stop_event):
    """Module 2: Detection và tracking với tối ưu hóa"""
    # Thiết lập device tối ưu cho Raspberry Pi
    device = torch.device('cpu')  # Luôn sử dụng CPU trên Pi
    yolo_model = YOLO(weights[0])
    names = yolo_model.model.names
    tracker_args = BYTETrackerArgs()
    tracker = BYTETracker(
        track_thresh=tracker_args.track_thresh,
        track_buffer=tracker_args.track_buffer,
        match_thresh=tracker_args.match_thresh,
        frame_rate=tracker_args.frame_rate,
        min_box_area=tracker_args.min_box_area,
        names=names
    )
    
    while not stop_event.is_set():
        if frame_queue.empty():
            time.sleep(0.01)
            continue
            
        data = frame_queue.get()
        if data is None:
            detect_queue.put(None)
            break

        path, im, im0s, s, current_speed, safe_distance = data
        
        # Chuyển đổi sang tensor và normalize
        im = torch.from_numpy(im).to(device).float() / 255.0
        if len(im.shape) == 3:
            im = im[None]

        results = yolo_model.predict(source=im, conf=conf_thres, iou=iou_thres, device=device)
        pred = results[0].boxes.data

        # Tracking
        detections_for_tracker = []
        detections_for_distance = []
        if len(pred):
            pred = pred.clone()
            # Scale lại coordinates về kích thước gốc
            pred[:, :4] = scale_coords(im.shape[2:], pred[:, :4], im0s.shape).round()

            for *xyxy, conf, cls in reversed(pred):
                x1, y1, x2, y2 = [int(x.item()) for x in xyxy]
                c = int(cls.item())
                conf_score = conf.item()
                class_name = names[c]

                # Chỉ theo dõi người và phương tiện
                detections_for_tracker.append([x1, y1, x2, y2, conf_score])
                detections_for_distance.append((x1, y1, x2, y2, conf_score, class_name))
        else:
            detections_for_tracker = []
        # Tracker update
        if detections_for_tracker:
            detections_array = np.array(detections_for_tracker)
            bboxes = detections_array[:, :4]
            scores = detections_array[:, 4]
            class_ids = np.zeros(len(bboxes))
        else:
            bboxes, scores, class_ids = np.empty((0, 4)), np.empty((0,)), np.empty((0,))

        tracked_objects = tracker.update(bboxes, scores, class_ids, im0s)
        
        # Đưa kết quả vào queue
        detect_queue.put((path, im0s, s, current_speed, safe_distance, tracked_objects, detections_for_distance))