# feature_mlp_rule.py
import torch
import torch.nn as nn
import pandas as pd
import joblib
import numpy as np
from Features.angle import compute_angle
from Features.Distance_esimation import estimate_distance
import time
import cv2
import os

# Status mapping
STATUS_MAP = {
    0: ("crossing", (0, 255, 255)),
    1: ("normal", (0, 255, 0)),
    2: ("wrong-way", (0, 0, 255))
}

# Tải model một lần khi import
def load_mlp_model():
    """Tải MLP model một lần và cache lại"""
    preprocessor = joblib.load("preprocessor.pkl")
    device_torch = torch.device('cpu')  # Luôn sử dụng CPU trên Pi
    
    # Xác định input_dim
    _dummy = pd.DataFrame([{
        "x": 0.0, "dx": 0.0, "y": 0.0, "dy": 0.0,
        "angle_sin": 0.0, "angle_cos": 1.0,
        "distance": 0.0,
        "roi_side": 'None',
        "speed": 0.0
    }])
    input_dim = preprocessor.transform(_dummy).shape[1]
    
    class MLP(nn.Module):
        def __init__(self, input_dim, hidden_dim=64, hidden_dim_2=32, hidden_dim_3=16, dropout=0.3):
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(input_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(hidden_dim, hidden_dim_2),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(hidden_dim_2, hidden_dim_3),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(hidden_dim_3, 3)
            )
        def forward(self, x):
            return self.net(x)
    
    mlp_model = MLP(input_dim=input_dim)
    mlp_model.load_state_dict(torch.load("mlp_model.pth", map_location=device_torch))
    mlp_model.to(device_torch)
    mlp_model.eval()
    
    return preprocessor, mlp_model, device_torch

# Tải model ngay khi import
preprocessor, mlp_model, device_torch = load_mlp_model()

def feature_mlp_rule_process(detect_queue, output_queue, stop_event):
    """Module 3: Trích xuất đặc trưng, MLP predict và rule base - Tối ưu hóa"""
    position_history, angle_history = {}, {}
    last_audio_time = 0
    audio_cooldown = 5  # Giây

    while not stop_event.is_set():
        if detect_queue.empty():
            time.sleep(0.02)  # Tăng thời gian chờ
            continue
            
        data = detect_queue.get()
        if data is None:
            output_queue.put(None)
            break

        path, im0, s,current_speed, safe_distance, tracked_objects, detections_for_distance = data
        
        # Xác định kích thước frame và ROI
        FRAME_WIDTH, FRAME_HEIGHT = im0.shape[1], im0.shape[0]
        ROI_X_MIN_RIGHT, ROI_X_MAX_RIGHT = int(FRAME_WIDTH * 0.50), int(FRAME_WIDTH * 0.95)
        ROI_Y_MIN_RIGHT, ROI_Y_MAX_RIGHT = int(FRAME_HEIGHT * 0.10), int(FRAME_HEIGHT * 0.70)
        ROI_X_MIN_LEFT, ROI_X_MAX_LEFT = int(FRAME_WIDTH * 0.05), int(FRAME_WIDTH * 0.4999)
        ROI_Y_MIN_LEFT, ROI_Y_MAX_LEFT = int(FRAME_HEIGHT * 0.10), int(FRAME_HEIGHT * 0.70)
        EGO_POSITION = (FRAME_WIDTH // 2, FRAME_HEIGHT)

        all_objects = {}

        # Xác định objects và ROI
        for obj in tracked_objects:
            x, y, w, h = obj["tlwh"]
            centroid_x, centroid_y = x + w / 2, y + h / 2
            centroid = (centroid_x, centroid_y)
            track_id = obj["track_id"]

            roi_side = None
            if ROI_X_MIN_RIGHT <= centroid_x <= ROI_X_MAX_RIGHT and ROI_Y_MIN_RIGHT <= centroid_y <= ROI_Y_MAX_RIGHT:
                roi_side = 'right'
            elif ROI_X_MIN_LEFT <= centroid_x <= ROI_X_MAX_LEFT and ROI_Y_MIN_LEFT <= centroid_y <= ROI_Y_MAX_LEFT:
                roi_side = 'left'

            if roi_side is not None:
                all_objects[track_id] = {"centroid": centroid, "roi": roi_side}

        # Xử lý từng object
        crossing_detected = False
        wrong_way_detect = False
        for obj_id, obj_data in all_objects.items():
            centroid, roi_side = obj_data['centroid'], obj_data['roi']
            
            # Vẽ ID
            cv2.putText(im0, f"ID:{obj_id}", (int(centroid[0]) - 20, int(centroid[1]) - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)  # Giảm kích thước font

            # Estimate distance
            object_distance = 0.0
            for (x1, y1, x2, y2, conf, label) in detections_for_distance:
                if (x1 <= centroid[0] <= x2) and (y1 <= centroid[1] <= y2):
                    object_distance = estimate_distance(
                        bbox=(x1, y1, x2, y2),
                        class_name=label,
                        frame_width=FRAME_WIDTH,
                        horizontal_fov=130
                    )
                    break

            # Tính góc
            angle, angle_sin, angle_cos = compute_angle(centroid[0], centroid[1], EGO_POSITION)

            # Lưu lịch sử
            if obj_id not in position_history:
                position_history[obj_id], angle_history[obj_id] = [], []

            position_history[obj_id].append((centroid[0], centroid[1]))
            angle_history[obj_id].append(angle)

            # Giữ chỉ 5 điểm gần nhất (giảm từ 10)
            MAX_HISTORY = 10
            if len(position_history[obj_id]) > MAX_HISTORY:
                position_history[obj_id] = position_history[obj_id][-MAX_HISTORY:]
            if len(angle_history[obj_id]) > MAX_HISTORY:
                angle_history[obj_id] = angle_history[obj_id][-MAX_HISTORY:]

            # Tính toán thay đổi
            x_change, y_change, angle_change = 0.0, 0.0, 0.0
            status_mlp = "normal"

            # Nếu có đủ lịch sử, thực hiện dự đoán MLP
            if len(position_history[obj_id]) >= MAX_HISTORY:
                x_coords = [p[0] for p in position_history[obj_id]]
                y_coords = [p[1] for p in position_history[obj_id]]
                angle_coords = angle_history[obj_id]
                x_change = x_coords[-1] - x_coords[0]
                y_change = y_coords[-1] - y_coords[0]
                angle_change = angle_coords[-1] - angle_coords[0]

                # Tạo feature vector
                X_df = pd.DataFrame([{
                    "x": float(centroid[0]),
                    "dx": float(x_change),
                    "y": float(centroid[1]),
                    "dy": float(y_change),
                    "angle_sin": float(angle_sin),
                    "angle_cos": float(angle_cos),
                    "distance": float(object_distance),
                    "roi_side": roi_side if roi_side is not None else 'none',
                    "speed": float(current_speed if current_speed is not None else 0.0)
                }])
                
                try:
                    X_scaled = preprocessor.transform(X_df)
                    X_tensor = torch.tensor(X_scaled, dtype=torch.float32).to(device_torch)
                    with torch.no_grad():
                        outputs = mlp_model(X_tensor)
                        pred_idx = int(outputs.argmax(1).cpu().numpy()[0])
                        status_mlp, mlp_color = STATUS_MAP.get(pred_idx, ("normal", (0, 255, 0)))
                except Exception as e:
                    status_mlp, mlp_color = "normal", (0, 255, 0)

            # Rule-based combination với MLP result
            status_mlp = status_mlp.lower() if isinstance(status_mlp, str) else str(status_mlp)
            status = "normal"
            color = (0, 255, 0)

            if roi_side == 'left':
                if abs(angle_change) > 5 and abs(x_change > 5) and status_mlp =='crossing':
                    status = "crossing"
                    color = (0, 255, 255)
                    crossing_detected = True
                else:
                    status = "normal"
                    color = (0, 255, 0)
            elif roi_side == 'right':
                if y_change > 5 and status_mlp in ('crossing', 'wrong-way'):
                    status = "wrong-way"
                    color = (0, 0, 255) 
                    wrong_way_detect = True
                elif abs(x_change) > 5 and abs(angle_change) > 5 and status_mlp == 'crossing':
                    status = "crossing"
                    color = (0, 255, 255)
                    crossing_detected = True
                else:
                    status = "normal"
                    color = (0, 255, 0)
                    
            # Vẽ kết quả lên frame
            cv2.putText(im0, status, (int(centroid[0]) - 20, int(centroid[1]) - 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)  # Giảm kích thước font
            cv2.circle(im0, (int(centroid[0]), int(centroid[1])), 3, color, -1)  # Giảm kích thước circle

        # Vẽ ROI và EGO position
        cv2.rectangle(im0, (ROI_X_MIN_RIGHT, ROI_Y_MIN_RIGHT), (ROI_X_MAX_RIGHT, ROI_Y_MAX_RIGHT), (0, 255, 0), 1)
        cv2.rectangle(im0, (ROI_X_MIN_LEFT, ROI_Y_MIN_LEFT), (ROI_X_MAX_LEFT, ROI_Y_MAX_LEFT), (0, 255, 0), 1)
        cv2.circle(im0, EGO_POSITION, 5, (0, 0, 255), -1)

        # Xử lý audio cảnh báo
        current_time = time.time()
        if crossing_detected and (current_time - last_audio_time) > audio_cooldown:
            play_audio("Phía trước có crossing")
            last_audio_time = current_time
        if wrong_way_detect and (current_time - last_audio_time) > audio_cooldown:
            play_audio("Bên phải có người đi ngược chiều")
            last_audio_time = current_time
        # Đưa frame đã xử lý vào output queue
        output_queue.put((path, im0, s,current_speed, safe_distance))

def play_audio(message):
    """Phát audio thông báo - Tối ưu hóa"""
    # Sử dụng os.system thay vì thư viện phức tạp
    # Giả sử đã cài đặt espeak
    os.system(f'espeak -v vi "{message}" &')  # Chạy trong background