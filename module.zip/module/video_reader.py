# video_reader.py
import cv2
from utils.dataloaders import LoadImages, LoadStreams
from utils.general import check_file
from pathlib import Path
import time
from Features.Safe_distance import safe_distance_estimation

def video_reader_process(source, imgsz, stride, frame_queue, stop_event):
    """Module 1: Đọc video/webcam, tính speed + safe_distance trước khi resize, đưa frames vào queue"""
    source = str(source)
    is_file = Path(source).suffix[1:] in (
        ['jpg', 'jpeg', 'png', 'bmp', 'tiff', 'tif', 'dng', 'webp', 'mpo'] +
        ['mov', 'avi', 'mp4', 'mpg', 'mpeg', 'm4v', 'wmv', 'mkv']
    )
    is_url = source.lower().startswith(('rtsp://', 'rtmp://', 'http://', 'https://'))
    webcam = source.isnumeric() or source.endswith('.txt') or (is_url and not is_file)

    if is_url and is_file:
        source = check_file(source)

    if webcam:
        cap = cv2.VideoCapture(int(source) if source.isnumeric() else source)
        # cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        # cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        # cap.set(cv2.CAP_PROP_FPS, 15)

        while not stop_event.is_set():
            ret, frame = cap.read()
            if not ret:
                break

            # Tính toán speed + safe_distance trước khi resize
            # current_speed, safe_distance = safe_distance_estimation(frame)

            # Resize cho đồng bộ pipeline
            # frame = cv2.resize(frame, (1280, 960))
            frame_queue.put(("webcam", None, frame, None, current_speed, safe_distance))

            time.sleep(0.03)  # ~30 FPS

        cap.release()

    else:
        dataset = LoadImages(source, img_size=imgsz, stride=stride, auto=True)

        for data in dataset:
            if stop_event.is_set():
                break

            # Flexible unpacking: path, im, im0s luôn có; phần còn lại gom vào rest
            path, im, im0s, *rest = data
            # Lấy thêm thông tin nếu có (vid_cap, s)
            vid_cap, s = (rest + [None, None])[:2]

            # Tính toán speed + safe_distance trên frame gốc
            current_speed, safe_distance = safe_distance_estimation(im0s)

            # Resize để tránh out-of-memory
            # if im0s.shape[1] > 1280:
            #     im0s = cv2.resize(im0s, (1280, 960))

            frame_queue.put((path, im, im0s, s, current_speed, safe_distance))

    frame_queue.put(None)  # báo hiệu hết video
