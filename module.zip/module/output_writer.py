# output_writer.py
import cv2
from pathlib import Path
import time
import os

def output_writer_process(output_queue, stop_event, project, name, view_img, nosave, exist_ok):
    """Xuất video kết quả và xử lý audio - Tối ưu hóa"""
    from utils.general import increment_path
    
    save_dir = increment_path(Path(project) / name, exist_ok=exist_ok)
    save_dir.mkdir(parents=True, exist_ok=True)
    
    vid_writer = None
    vid_path = None
    
    # Codec & cấu hình đầu ra
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')  
    output_fps = 30
    output_size = (2560, 1920)
    
    while not stop_event.is_set():
        if output_queue.empty():
            time.sleep(0.02)
            continue
            
        data = output_queue.get()
        if data is None:
            break

        path, im0, s, current_speed, safe_distance = data  # chỉ còn 3 giá trị

        # Resize frame đầu ra
        # if im0.shape[1] > 640:
        #     im0 = cv2.resize(im0, output_size)
        
        p = Path(path)
        save_path = str(save_dir / p.name)
        
        # Hiển thị frame nếu cần
        if view_img:
            cv2.imshow(str(p), im0)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                stop_event.set()
                break

        # Lưu frame nếu cần
        if not nosave:
            # Nếu là ảnh
            if p.suffix.lower() in ['.jpg', '.jpeg', '.png', '.bmp']:
                cv2.imwrite(save_path, im0)
            else:
                # Nếu là video
                if vid_path != save_path:
                    vid_path = save_path
                    if vid_writer is not None:
                        vid_writer.release()
                    
                    save_path = str(Path(save_path).with_suffix('.mp4'))
                    vid_writer = cv2.VideoWriter(save_path, fourcc, output_fps, output_size)
                
                vid_writer.write(im0)
    
    # Dọn dẹp
    if vid_writer is not None:
        vid_writer.release()
    cv2.destroyAllWindows()
